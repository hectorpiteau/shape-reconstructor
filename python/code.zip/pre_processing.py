import re


class PreProcessor:
    def __init__(self) -> None:
        pass

    def process(self, data):
        return data