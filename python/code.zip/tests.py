import utils

print(utils.create_random_int_arrays(10,15))